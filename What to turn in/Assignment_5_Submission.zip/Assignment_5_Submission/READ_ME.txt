All you have to do is run the bash script (run.sh)
To do that, do the following:

1.You must copy all the code that is in my Bash scipt into a new empty script and run it (in the same location) due to canvas corrupting my scripts (as in the past). The TA's in the past had this problem while grading my homework and were able to get it running.
2. chmod +x run.sh
3. ./run.sh

FYI, the files named "tree.test.data" and "tree.train.data" are the data files that my bagged forest generated. I used them while getting assist in getting my accuracies and debugging so I did not have to re-run the entire bagged forest, but for my submission they are not used. I am providing them though.