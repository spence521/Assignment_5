All you have to do is run the bash script (run.sh)
To do that, do the following:

1.Type: ./run.sh

FYI, the files named "tree.test.data" and "tree.train.data" are the data files that my bagged forest generated. I used them while getting assist in getting my accuracies and debugging so I did not have to re-run the entire bagged forest, but for my submission they are not used. I am providing them though.
